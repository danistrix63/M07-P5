package com.example.m07_p5

data class FoodItem(
    val id: Int,
    var name: String,
    var quantity: String,
    var date: String
)