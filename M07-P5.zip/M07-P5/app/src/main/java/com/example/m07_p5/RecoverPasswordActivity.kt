package com.example.m07_p5

import android.os.Bundle

class RecoverPasswordActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.recover_password)
    }
}
