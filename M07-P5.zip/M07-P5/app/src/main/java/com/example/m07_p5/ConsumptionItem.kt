package com.example.m07_p5

data class ConsumptionItem(
    val name: String,
    val calories: String,
    val date: String
)